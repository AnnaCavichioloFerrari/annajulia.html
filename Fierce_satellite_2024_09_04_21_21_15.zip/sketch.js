function setup() {
  createCanvas(100, 100);

  background(200);

  triangle(30, 75, 58, 20, 86, 75);

  describe('A white triangle with a black outline on a gray canvas.');
}